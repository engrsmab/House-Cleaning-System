path = "Login/Img/"
path2 = "Files/Img/"
Images = [path+"logo.png",path+"edit-user-24.png",path+"key-3-24.png",path2+"home-32.png",path2+"group-32.png",path2+"gear-2-32.png",path2+"account-logout-32.png"]

TopColor = "#0384fc"
BackColor = "blue"
ForColor = "white"

small_font = ("Times 11")
Normal_Font = ("Times 16")
big_Font = ("Times 20")
huge_font = ("Times 40 bold")

full_width = 900
full_height = 700

width = 300
height = 380
x = 900//2 - width//2
y = 700//2 - height//2
