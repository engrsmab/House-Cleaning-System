import sqlite3
# Function to set query commas, question marks and equelity of statememnt
def Where_Query(value,exp):

    where_final = ""
    for i in range(len(value)):
        if i != 0:
            if exp == "del":
               where_final += " AND "
            else:
                where_final += ","
        where_final += str(value[i]) + "=?"
    return where_final

# Function to set query column values saperated by comma and question mark (where needed)
def Set_Columns(col):
    cols = ""
    unknowns = ""
    for i in range(len(col)):
        if i != 0:
            unknowns += ","
            cols += ","
        unknowns += "?"
        cols += col[i]
    return cols,unknowns
# Function to decide query of database according to passed arguments
def Query(parent,col=None, value=None, query=None,where=None):
    database = parent['database']
    table = parent['table']
    conn = sqlite3.connect(database)
    cursor = conn.cursor()

    if col != None:
        cols,unknowns = Set_Columns(col)
    else:
        cols = unknowns = ""
    # Query for Insert values
    if query == "INSERT":
        statement= f"INSERT INTO {table}({cols})VALUES({unknowns})"
    # Query for Create tables
    elif query == "CREATE":
        statement = f"CREATE TABLE IF NOT EXISTS {table}({cols})"
    # Query for Select data with and without specific condition of "where"
    elif query == "SELECT":
        if where != None:
           where_final = Where_Query(where,"del")
           statement = f"SELECT {cols} FROM {table} WHERE {where_final}"
        else:
            statement = f"SELECT {cols} FROM {table}"
    # Query of update row
    elif query == "UPDATE":
        cols_final = Where_Query(col,"=?")
        where_final = Where_Query(where,"=?")
        statement = f"UPDATE {table} SET {cols_final} WHERE {where_final}"
    # Query to delete row
    elif query == "DELETE":
        where_final = Where_Query(where,"del")
        statement = f"DELETE FROM {table} WHERE {where_final}"
    else:
        statement = "NONE"
    # print(statement)
    if statement != "NONE":
        # try:
        # execution of create query 
        if query == "CREATE" or (query == "SELECT" and where == None):
            cursor.execute(statement)
        else:
            # execution of all other queries
            cursor.execute(statement, value)
        if query == "SELECT":
            # fetching results of select query
            result = cursor.fetchall()
        else:
            result = "Done"
        # except sqlite3.Error as err:
        #     return err
    conn.commit()
    cursor.close()
    conn.close()
    return result