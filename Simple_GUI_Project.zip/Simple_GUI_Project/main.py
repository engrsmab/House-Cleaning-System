# Importing required modules and files
from tkinter import *
from Login.Login import Backend,full_height,full_width,Images
from Login.Login import LoginWin
from Register import RegisterWin
from Dashboard import Dashboard
import socket
# Checking operating system to start GUI
pc_name = str(socket.gethostname())
pc_name = pc_name.split("-")
mac = False
if pc_name[0] == "MacBook" or pc_name[0] == "Macbook" or pc_name[0] == "Macbooks":
    from tkmacosx import Button
    pc_name = pc_name[0]
    mac = True
# Creating Root Window of GUI
root = Tk()
root.geometry(f"{full_width}x{full_height}")
root.title("House Cleaning System")
Imgs = []
# Appending required Images
for i in range(len(Images)):
        Imgs.append(PhotoImage(file=Images[i]))

# Login Function for Login Screen
def Login_func(entries,check):
    data = Backend.Login_Backend(entries,check)
    if type(data) != str:
        root.destroy()
        open_dash = Dashboard(data)
        open_dash.change_tab(0)
        # btns = open_dash.Buttons
        # for i in range(len(btns)):
        #     if i != 1: 
        #        btns[i]['command'] =
        #     else:
                
        #         btns[i]['command'] = lambda frame_win = open_dash.tab_frame:RegisterWin(frame_win,frame=None)
         
                
        
# Registration Screen Function for new registration
def Register_open():
    register = RegisterWin(root,login.frame)
    reg_btns = register.Buttons
    reg_cmnd = [lambda entries = register.Entries: Backend.Submit(entries),lambda root=root,frame=register.frame:LoginWin(root=root,Imgs=Imgs,frame=frame)]
    for btns in range(len(reg_btns)):
        reg_btns[btns]['command'] = reg_cmnd[btns]

# Checking for remembered members
data,status = Backend.Remember_me(window="start")
if status:
    print(data)

# First Login Screen
login = LoginWin(root=root,Imgs=Imgs)
login_btns = login.buttons
login_cmnd = [lambda entries=login.Entries,check=login.check:Login_func(entries,check),lambda :Register_open()]
for btn in range(len(login_btns)):
    login_btns[btn]['command'] = login_cmnd[btn]
root.mainloop()
